import SwiftUI

struct ContentView: View {
    @State private var question = ""
    @State private var answer = "Welcome to Lamar. Ask me to find jobs, income opportunities, learning resources, or solve a problem."
    @State private var scanning = false
    @State private var showResult = false

    let missions = [
        ("Find Jobs", "Search current openings"),
        ("Make Income", "Find realistic earning paths"),
        ("Learn", "Build a useful skill plan"),
        ("Business", "Explore practical ideas")
    ]

    var body: some View {
        TabView {
            NavigationStack {
                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        Text("Lamar").font(.system(size: 40, weight: .bold))
                        Text("Your personal AI opportunity assistant")
                            .foregroundStyle(.secondary)

                        Button {
                            Task {
                                scanning = true
                                defer { scanning = false }
                                do {
                                    answer = try await APIClient.shared.scan()
                                } catch {
                                    answer = "Connect Lamar to your backend to run live searches."
                                }
                                showResult = true
                            }
                        } label: {
                            HStack {
                                Image(systemName: scanning ? "hourglass" : "sparkles")
                                Text(scanning ? "Scanning..." : "Run Opportunity Scan")
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(.blue)
                            .foregroundStyle(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                        }

                        Text("Quick missions").font(.headline)
                        ForEach(missions, id: \.0) { item in
                            Button { question = item.1 } label: {
                                HStack {
                                    VStack(alignment: .leading) {
                                        Text(item.0).font(.headline)
                                        Text(item.1).font(.subheadline)
                                            .foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    Image(systemName: "chevron.right")
                                }
                                .padding()
                                .background(Color(.secondarySystemBackground))
                                .clipShape(RoundedRectangle(cornerRadius: 14))
                            }
                            .foregroundStyle(.primary)
                        }
                    }
                    .padding()
                }
                .navigationTitle("Home")
            }
            .tabItem { Label("Home", systemImage: "house") }

            NavigationStack {
                VStack(spacing: 14) {
                    TextField("Ask Lamar anything...", text: $question, axis: .vertical)
                        .textFieldStyle(.roundedBorder)
                    Button("Ask Lamar") {
                        Task {
                            do {
                                answer = try await APIClient.shared.ask(question)
                            } catch {
                                answer = "I couldn't reach the Lamar server. Check your backend URL."
                            }
                            showResult = true
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    Spacer()
                }
                .padding()
                .navigationTitle("Ask")
            }
            .tabItem { Label("Ask", systemImage: "message") }

            NavigationStack {
                VStack(alignment: .leading, spacing: 12) {
                    Text("Saved opportunities").font(.title2.bold())
                    Text("Saved items will appear here after the backend is connected.")
                        .foregroundStyle(.secondary)
                    Spacer()
                }
                .padding()
                .navigationTitle("Saved")
            }
            .tabItem { Label("Saved", systemImage: "bookmark") }

            NavigationStack {
                Form {
                    Section("About Lamar") {
                        Text("Research, organize and act on useful opportunities.")
                        Text("Important external actions should require your approval.")
                    }
                }
                .navigationTitle("Profile")
            }
            .tabItem { Label("Profile", systemImage: "person") }
        }
        .sheet(isPresented: $showResult) {
            NavigationStack {
                ScrollView {
                    Text(answer)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding()
                }
                .navigationTitle("Lamar")
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("Done") { showResult = false }
                    }
                }
            }
        }
    }
}
