# Lamar Xcode setup

1. Open `Lamar.xcodeproj` in Xcode on a Mac.
2. Select the **Lamar** target.
3. Under **Signing & Capabilities**, choose your Apple Team.
4. Change the bundle identifier if `com.lamar.assistant` is unavailable.
5. Set `APIClient.baseURL` to the HTTPS address of your Lamar backend.
6. Select your iPhone as the run destination and Build/Run.
7. For TestFlight, Archive the app and upload it to App Store Connect.

Apple requires the bundle ID used by the Xcode project to match the App Store Connect app record for distribution.
