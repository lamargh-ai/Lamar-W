import SwiftUI

@main
struct LamarApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
