import Foundation

final class APIClient {
    static let shared = APIClient()
    var baseURL = "https://YOUR-LAMAR-BACKEND.example.com"

    func ask(_ message: String) async throws -> String {
        let url = URL(string: baseURL + "/api/ask")!
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try JSONEncoder().encode(["message": message, "context": "iPhone"])
        let (data, response) = try await URLSession.shared.data(for: req)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            throw URLError(.badServerResponse)
        }
        struct Result: Decodable { let answer: String }
        return try JSONDecoder().decode(Result.self, from: data).answer
    }

    func scan(location: String = "Ghana") async throws -> String {
        let url = URL(string: baseURL + "/api/opportunities/scan")!
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try JSONSerialization.data(withJSONObject: [
            "categories": ["jobs","income","learning","business"],
            "location": location
        ])
        let (data, response) = try await URLSession.shared.data(for: req)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else {
            throw URLError(.badServerResponse)
        }
        struct Result: Decodable { let results: String }
        return try JSONDecoder().decode(Result.self, from: data).results
    }
}
