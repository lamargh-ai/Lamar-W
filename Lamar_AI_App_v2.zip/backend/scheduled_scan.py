import os, requests
url = os.getenv("LAMAR_API_URL", "http://127.0.0.1:8000") + "/api/opportunities/scan"
r = requests.post(url, json={
    "categories": ["jobs","income","learning","business"],
    "location": os.getenv("LAMAR_LOCATION", "Ghana")
}, timeout=120)
print(r.status_code)
print(r.text)
