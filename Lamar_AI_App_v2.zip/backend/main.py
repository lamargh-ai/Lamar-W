import os, sqlite3
from datetime import datetime, timezone
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()
app = FastAPI(title="Lamar API", version="1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])

DB = os.getenv("LAMAR_DB", "lamar.db")
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
MODEL = os.getenv("OPENAI_MODEL", "gpt-5.6-luna")

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    c.execute("""CREATE TABLE IF NOT EXISTS opportunities(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT, category TEXT, summary TEXT, url TEXT,
      location TEXT, deadline TEXT, created_at TEXT, status TEXT DEFAULT 'saved'
    )""")
    c.commit()
    return c

class Ask(BaseModel):
    message: str
    context: str = ""

class Scan(BaseModel):
    categories: list[str] = ["jobs", "income", "learning", "business"]
    location: str = "Ghana"

class Status(BaseModel):
    status: str

@app.get("/api/health")
def health():
    return {"ok": True, "app": "Lamar"}

@app.post("/api/ask")
def ask(body: Ask):
    prompt = f"""You are Lamar, a practical personal AI assistant.
Help the user make progress with accurate, current information.
Use web search when current information is needed.
Be concrete: explain the situation, give steps, risks, and useful links.
Never claim an external action was completed unless it actually was.

User message:
{body.message}

Context:
{body.context}
"""
    r = client.responses.create(
        model=MODEL,
        tools=[{"type": "web_search_preview"}],
        input=prompt
    )
    return {"answer": r.output_text}

@app.post("/api/opportunities/scan")
def scan(body: Scan):
    prompt = f"""Find current, legitimate opportunities relevant to the user.
Location: {body.location}
Categories: {", ".join(body.categories)}
For each opportunity give: title, category, summary, location,
deadline if known, and a direct application/source URL.
Prioritize currently open and actionable opportunities.
Do not invent URLs or deadlines.
"""
    r = client.responses.create(
        model=MODEL,
        tools=[{"type": "web_search_preview"}],
        input=prompt
    )
    return {"results": r.output_text,
            "scanned_at": datetime.now(timezone.utc).isoformat()}

@app.get("/api/opportunities")
def opportunities():
    c = db()
    return [dict(x) for x in c.execute(
        "SELECT * FROM opportunities ORDER BY id DESC").fetchall()]

@app.post("/api/opportunities")
def save(item: dict):
    c = db()
    cur = c.execute("""INSERT INTO opportunities
      (title,category,summary,url,location,deadline,created_at,status)
      VALUES(?,?,?,?,?,?,?,?)""",
      (item.get("title",""), item.get("category",""), item.get("summary",""),
       item.get("url",""), item.get("location",""), item.get("deadline",""),
       datetime.now(timezone.utc).isoformat(), "saved"))
    c.commit()
    return {"id": cur.lastrowid}

@app.patch("/api/opportunities/{oid}")
def update(oid: int, body: Status):
    c = db()
    c.execute("UPDATE opportunities SET status=? WHERE id=?",
              (body.status, oid))
    c.commit()
    return {"ok": True}
