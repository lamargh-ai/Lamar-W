# Lamar — Personal AI Assistant

iPhone-first AI assistant starter for web research, jobs, income opportunities,
learning, business ideas, saved opportunities, and proactive scans.

## Structure
- ios/Lamar — SwiftUI iPhone app source
- backend — FastAPI + OpenAI Responses API
- web — installable web/PWA interface
- docs — deployment notes

## Quick start
1. Copy backend/.env.example to backend/.env
2. Add your OpenAI API key.
3. `pip install -r backend/requirements.txt`
4. `uvicorn main:app --reload --host 0.0.0.0 --port 8000`

Never put the OpenAI API key in the iPhone app.


## Native Xcode project
The package now includes `ios/Lamar.xcodeproj` plus app metadata, so you can open Lamar directly in Xcode and configure Apple signing.
