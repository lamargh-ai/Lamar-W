# Lamar deployment

Deploy `backend/` to a Python/FastAPI or Docker host and set OPENAI_API_KEY.
Use HTTPS in production.

For iPhone:
1. Open the Swift source in Xcode.
2. Create an iOS App target named Lamar.
3. Add the three Swift files.
4. Set APIClient.baseURL to your HTTPS backend.
5. Use Xcode signing for device/TestFlight distribution.

For proactive scans, run scheduled_scan.py with cron or a cloud scheduler.
For production push notifications, add APNs credentials and a notification
service. Keep OpenAI/APNs private credentials on the server.

Before public launch add authentication, per-user data isolation, rate
limiting, audit logs, secure secrets, HTTPS, and server-side authorization.
